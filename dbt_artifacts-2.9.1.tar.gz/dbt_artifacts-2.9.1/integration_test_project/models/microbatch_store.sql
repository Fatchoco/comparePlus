select
    5 as store_id,
    'Lower Manhattan' as store_name

union all

select
    8 as store_id,
    'Hells Kitchen' as store_name
