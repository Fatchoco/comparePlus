{{
    config(
        alias = 'my_alias',
    )
}}

select
    1 as id,
    'banana' as fruit
