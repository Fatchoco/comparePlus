select 1 as failures from (select 2 as two) as foo where 1 = 2

