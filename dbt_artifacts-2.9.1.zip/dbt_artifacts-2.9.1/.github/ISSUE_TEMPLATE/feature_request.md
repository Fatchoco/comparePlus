---
name: Feature Request
about: Request something new
title: '[Feature]: '
labels: enhancement
assignees: ''

---

## Overview

<!-- In 1-2 sentences, describe the feature you'd like to see -->

## What problem would this solve?

<!-- Provide some details of the context, and how this would be useful -->

## Would you be willing to contribute?

- [ ] Yes - I'm on it!
- [ ] Yes, but I'd need help getting started.
- [ ] No
